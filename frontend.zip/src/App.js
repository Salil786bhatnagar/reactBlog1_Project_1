import React from 'react';
import './Custom.css'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Dashboard from './component/User/Dashboard';
import Registration from './component/User/Ragistration'
import Userdisplay from './component/User/Userdisplay';


function App(props) {
   
  return (
    <>
      
  
      <ol>
       {/* <li>{showDetails.Mytestpage}</li>
       <li>{showDetails.testcoding}</li>
       <li>{showDetails.Mycoding()}</li> */}
       {/* <li>{showDetails.default}</li>
       <li>{showDetails.testcoding}</li>
       <li>{showDetails.Mycoding()}</li> */}
       {/* <li><span>Addition:-</span>{Add(20,2)}</li>
       <li><span>Subtraction:-</span>{Sub(45,6)}</li>
       <li><span>Multipli:-</span>{Mul(6,6)}</li>
       <li><spna>Devision:-</spna>{Div(64,7)}</li> */}
      </ol>
     <div className="divclassName"> 
     {/* <h1> List of top 5 Netflix Web Series in 2021 </h1>
    <ul> 
      <li>
      {Ndata.map(ncard)}   
       <Fvs/>
       {
       (Fwebseries === "Netflex")? <Netflex/> : <Amazon/>
       }
       </li>
    
     
     </ul>  */}

      {/* <Cards
       imgsrc={Ndata[0].imgsrc}
       title={Ndata[0].title}
       sname={Ndata[0].sname}
       link={Ndata[0].link}
       /> */}
      </div>

      {/* <Showimages/> */}

      <Router>
      <Route
          exact
          strict
          path="/"
          component={Dashboard}
          history={props.history}
         /> 

        <Route
          exact
          strict
          path="/Userdisplay"
          component={Userdisplay}
          history={props.history}
         />     

<Route
exact
strict
path="/Registration"
component={Registration}
history={props.history}
/> 
       
      </Router>
       
    </>
  );
}

export default App;
