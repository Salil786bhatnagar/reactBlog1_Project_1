import React from 'react'

export default function text() {
    return (
        <div>
            test data
        </div>
    )
}
